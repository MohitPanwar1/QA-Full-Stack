package poc_4;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class poc_method {
	WebDriver dr;
	double price1,price2;
	Logger log;
public void login(WebDriver dr1) {
    dr=dr1;
    log=Logger.getLogger("devpinoyLogger");
	
	dr.get("http://automationpractice.com/index.php");
	
	dr.findElement(By.xpath("/html/body/div/div[1]/header/div[2]/div/div/nav/div[1]/a")).click();
	dr.findElement(By.id("email")).sendKeys("abcde12321@gmail.com");
	dr.findElement(By.id("passwd")).sendKeys("Mpqwer");
	dr.findElement(By.xpath("//*[@id=\"SubmitLogin\"]/span")).click();
}
public void verify_full_name()
{
	String s=dr.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a/span")).getText();
	if(s.equals("M P"))
	{
		System.out.print("Full name verified");
		log.info("Full name verified");
	}
	else
	{
		System.out.print("Full name not verified");
		log.info("Full name not verified");
	}
    
}
public void add_to_cart()
{
	WebDriverWait wt=new WebDriverWait(dr,200);
   	wt.until(ExpectedConditions.elementToBeClickable(By.className("sf-with-ul")));
	WebElement we=dr.findElement(By.className("sf-with-ul"));
    Actions act1=new Actions(dr);
    Action set=act1.moveToElement(we).build();
    set.perform();	
    wt=new WebDriverWait(dr,60);
   	wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[2]/a")));
    dr.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[2]/a")).click();
    wt=new WebDriverWait(dr,60);
    wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div[2]/div/div[3]/div[2]/ul/li/div/div[1]/div/a[1]/img")));
    
    dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div[2]/ul/li/div/div[1]/div/a[1]/img")).click();
    dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div/div/div[4]/form/div/div[3]/div[1]/p/button/span")).click();
    wt=new WebDriverWait(dr,60);
    wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/span/span")));
    dr.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/span/span")).click();
    wt=new WebDriverWait(dr,300);
    wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[3]/a")));
    dr.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[3]/a")).click();
    dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div[2]/ul/li/div/div[1]/div/a[1]/img")).click();
    dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div/div/div[4]/form/div/div[2]/p[1]/a[2]/span")).click();
    dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div/div/div[4]/form/div/div[3]/div[1]/p/button/span")).click();
    wt=new WebDriverWait(dr,60);
    wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/span/span")));
    dr.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/a/span")).click();
    
    /*dr.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[2]/div[2]/a[1]/span")).click();
    wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/span/span")));
    dr.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/span/span")).click();
    dr.findElement(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[3]/a")).click();
    
    we=dr.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[1]/div/a[1]/img"));
    set=act1.moveToElement(we).build();
    set.perform();
    dr.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[2]/div[2]/a[2]/span")).click();
    dr.findElement(By.xpath("//*[@id=\"quantity_wanted_p\"]/a[2]/span")).click();
    dr.findElement(By.xpath("//*[@id=\"add_to_cart\"]/button/span")).click();
    wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a/span")));
    dr.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a/span")).click();
    */
}
public boolean verify_product_name()
{
	String s1=dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[1]/td[2]/p/a")).getText();
	String s2=dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[2]/td[2]/p/a")).getText();
	if((s1.equals("Printed Dress"))&&(s2.equals("Faded Short Sleeve T-shirts")))
	{
		
		log.info("Dress name  verified");
		return true;
	}
	else
		{
		log.info("Dress name not verified");
		return false;
		}
	

}
public boolean unit_price()
{ 
	WebDriverWait wt1=new WebDriverWait(dr,60);
    wt1.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[1]/td[4]/span/span")));
	String p1=dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[1]/td[4]/span/span")).getText();
	p1=p1.substring(1);
	price1=Double.parseDouble(p1);
	String p2=dr.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[2]/td[4]/span/span")).getText();
	p2=p2.substring(1);
	price2=Double.parseDouble(p2);
	if((price1==26.00)&&(price2==16.51))
	{
		log.info("Unit price verified");
	
		return true;
	}
	else 
	{
		log.info("Unit price not verified");
		return false;
	}
	}
public boolean verify_total()
{
	String s1=dr.findElement(By.xpath("//*[@id=\"total_price\"]")).getText();
	s1=s1.substring(1);
	double total=Double.parseDouble(s1);
	double total1=price1+price2*2+2.00+0.00;
	System.out.println(total);
	System.out.println(total1);
	
	if((total==61.02)&&(total1==61.02))
	{
		log.info("Total is verified");
	
		return true;
	}
	else 
	{
		log.info("Total is not verified");
		return false;
	}
}
}

