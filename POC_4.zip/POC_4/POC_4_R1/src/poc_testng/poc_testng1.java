package poc_testng;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import poc_4.poc_method;

public class poc_testng1 extends poc_method{
	
	WebDriver dr;
	String nodeURL;
	@BeforeClass
	public void setup()throws MalformedURLException
	{
		
		nodeURL ="http://172.16.70.157:5566/wd/hub";
		DesiredCapabilities cap=DesiredCapabilities.firefox();
		
		cap.setBrowserName("firefox");
		cap.setPlatform(Platform.WINDOWS);
		dr=new RemoteWebDriver(new URL(nodeURL),cap);
	}
	@Test
	public void f2()
		{
		//System.setProperty("webdriver.gecko.driver","D:\\Driver\\geckodriver.exe" );
		//WebDriver dr=new FirefoxDriver();
		login(dr);
		verify_full_name();
	add_to_cart();
	}
  @Test
  public void f4()
  {
	  boolean b=verify_product_name();
	  Assert.assertEquals(b,true);
  }
  @Test
  public void f5()
  {
	  boolean b=unit_price();
	  Assert.assertEquals(b,true);
  }
  @Test
  public void f6()
  {
	  boolean b=verify_total();
	  Assert.assertEquals(b,true);
  }
}
