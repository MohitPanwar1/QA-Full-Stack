package poc_testng;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import poc_4.poc_method;

public class poc_testng extends poc_method{
	

  @Test
 public void f() {
	  System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
	  WebDriver dr=new ChromeDriver();
	  login(dr);
	  verify_full_name();
	  add_to_cart();
  }
 
//	@Test
//	public void f2()
//		{
//		System.setProperty("webdriver.gecko.driver","D:\\Driver\\geckodriver.exe" );
//		WebDriver dr=new FirefoxDriver();
//		login(dr);
//		verify_full_name();
//		add_to_cart();
//	}
  @Test
  public void f4()
  {
	  boolean b=verify_product_name();
	  Assert.assertEquals(b,true);
  }
  @Test
  public void f5()
  {
	  boolean b=unit_price();
	  Assert.assertEquals(b,true);
  }
  @Test
  public void f6()
  {
	  boolean b=verify_total();
	  Assert.assertEquals(b,true);
  }
 // @Test
// public void f3()
// {
//  System.setProperty("webdriver.ie.driver","D:\\Driver\\IEDriverServer.exe" );
//	WebDriver dr=new InternetExplorerDriver();
//	login(dr);
//	  verify_full_name();
//	  add_to_cart();
//}
}
