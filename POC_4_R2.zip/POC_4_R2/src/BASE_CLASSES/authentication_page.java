package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class authentication_page extends Home_page{
	@FindBy(xpath="//*[@id=\"SubmitLogin\"]/span")
	WebElement usubmit;
public boolean verify_page_title()
{
	String s=dr.getTitle();
	if(s.equals("Login - My Store"))
	{
		log.info("Login Page Title is verified");
		System.out.println("Login Page Title is verified");
		return true;
	}
	else
	{
		log.info("Login Page Title is not  verified");
		System.out.println("Login Page Title is not verified");
		return false;
	}
	}
public void send_values(String e,String p)
{
	PageFactory.initElements(dr,this);
	dr.findElement(By.id("email")).sendKeys(e);
	dr.findElement(By.id("passwd")).sendKeys(p);
	usubmit.click();	

}
}
