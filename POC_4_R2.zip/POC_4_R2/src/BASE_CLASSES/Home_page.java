package BASE_CLASSES;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Home_page {
	public WebDriver dr;
	public Logger log;
	
public void display_home_page()
{   
	System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
	dr=new ChromeDriver();
	dr.get("http://automationpractice.com/index.php");
	log=Logger.getLogger("devpinoyLogger");
}
public boolean verify_title_sig_in()
{
    String s=dr.getTitle();
    if(s.equals("My Store"))
    {
    	
    	log.info("Title is verified");
    	System.out.println("Title is verified");
    }
    else
    {
    	log.info("Title not is verified");
    	System.out.println("Title is not verified");
    }
    String s1=dr.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).getText();
    if(s1.equals("Sign in")) 
    {
    	log.info("Sign in is verified");
    	System.out.println("Sign in is verified");
    }
    else
    {
    	log.info("Sign in is not verified");
    	System.out.println("Sign in is not verified");
    }
    if(s.equals("My Store")&&s1.equals("Sign in"))
    {
    	dr.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();
    	return true;
    }
    else 
    	{
    	dr.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();
    	return false;
    	}
}
}
