package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

public class My_account extends authentication_page{
public String verify_account()
{
	String a;
	try
	{
	a=dr.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a/span")).getText();
	log.info("Login Successful");
	logout();
	return a;
	}
	catch(NoSuchElementException e)
	{
		a=dr.findElement(By.xpath("//*[@id=\"center_column\"]/div[1]/ol/li")).getText();
		log.info("Login failed");
		return a;
	}
	
}
public void logout()
{
dr.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[2]/a")).click();
log.info("Logout Successful");
}
}
