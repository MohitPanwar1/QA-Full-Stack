package TESTNG_TESTS;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BASE_CLASSES.My_account;
import UTILITIES.Excel_class;
public class testng_2 extends testng_1
{   String data[][];
	@BeforeClass
	public void read()
	{
		Excel_class ob=new Excel_class();
		data=ob.read_excel(1);
	}
	@DataProvider(name="logindataprovider")
	  public String[][] get_textdata()
	  {
		  
		  return data;
	  }
  @Test(dataProvider="logindataprovider")
  public void f3(String eid,String p,String r) {
	  send_values(eid,p);
	  f4(r);
  }
  
  public void f4(String r)
  {
	  String s=verify_account();
	  Assert.assertEquals(r, s);
  }
}
