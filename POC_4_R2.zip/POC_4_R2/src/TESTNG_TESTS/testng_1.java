package TESTNG_TESTS;

import org.testng.Assert;
import org.testng.annotations.Test;

import BASE_CLASSES.Home_page;
import BASE_CLASSES.My_account;
import BASE_CLASSES.authentication_page;


public class testng_1 extends My_account
{
  @Test
	  public void f() {
		  display_home_page();
		 
	  }
  @Test
  public void f1() {
	  boolean b=verify_title_sig_in();
	  Assert.assertEquals(b, true);
  }
  @Test
  public void f2() {
	  boolean b=verify_page_title();
	  Assert.assertEquals(b, true);
  }
 
  
}
