package UTILITIES;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel_class {
	public String[][] read_excel(int r)
	{
		String[][] s=new String[2][3];
	try {
		int c=1;
		File f=new File("C:\\Users\\mohit.panwar\\Documents\\POC_4_R2.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		XSSFRow row=sh.getRow(1);
		XSSFCell cell=row.getCell(c);
		String eid=cell.getStringCellValue();
		c++;
		cell=row.getCell(c);
		String passwd=cell.getStringCellValue();
		c++;
		cell=row.getCell(c);
		String result=cell.getStringCellValue();
		row=sh.getRow(2);
		c=1;
		cell=row.getCell(c);
		String eid1=cell.getStringCellValue();
		c++;
		cell=row.getCell(c);
		String passwd1=cell.getStringCellValue();
		c++;
		cell=row.getCell(c);
		String result1=cell.getStringCellValue();
		s[0][0]=eid;
		s[0][1]=passwd;
		s[0][2]=result;
		s[1][0]=eid1;
		s[1][1]=passwd1;
		s[1][2]=result1;
		
}
	catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return s;
	}
}
