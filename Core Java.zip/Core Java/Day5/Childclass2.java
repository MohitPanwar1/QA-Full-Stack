package prime_n0;
import libraryuse.Parentclass;

public class Childclass2 extends Parentclass{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method st
	}
	public void details()
	{
		//System.out.println(a);
		//System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}

}
