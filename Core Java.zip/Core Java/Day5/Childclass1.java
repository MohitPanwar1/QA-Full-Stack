package libraryuse;

public class Childclass1 extends Parentclass{
	public static void main(String args[])
	{
	Childclass1 ob=new Childclass1();
	ob.display();
	System.out.println(ob.b);
	System.out.println(ob.c);
	System.out.println(ob.d);
	}
}
