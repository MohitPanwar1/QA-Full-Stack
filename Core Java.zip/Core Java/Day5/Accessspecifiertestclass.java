package prime_n0;

public class Accessspecifiertestclass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Childclass2 ob=new Childclass2();
		ob.details();
	}
}
