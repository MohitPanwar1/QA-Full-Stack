package libraryuse;

public class Trycatch {
public static void main(String args[])
{
	try
	{
		int a=3,c=0;
int b[]={33,7,8,4,3};
System.out.println(b[7]+a/c);
System.out.println(b[3]);
System.out.println(b[7]);
System.out.println("hi");

	}
	catch(ArithmeticException e)
	{
		
		System.out.println("Inside Catch blk ArithmaticException");

	}
	catch(ArrayIndexOutOfBoundsException e)
	{
		
		System.out.println("Inside Catch blk ArrayIndexOutOfBoundsException");

	}
	System.out.println("Inside Catch blk");
}
}
