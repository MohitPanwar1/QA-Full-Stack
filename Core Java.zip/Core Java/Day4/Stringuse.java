package prime_n0;

public class Stringuse {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="I am learning Core Java",s1="Hello",s2="hello";
int p=0,i=0,c=0,l=s.length();
System.out.println("Length :"+l);
System.out.println(s1.compareTo(s2));
	while(p!=-1)
	{
	p=s.indexOf('a',i);
	i=p+1;
	c++;
	}
	System.out.println(c);
	}
}
