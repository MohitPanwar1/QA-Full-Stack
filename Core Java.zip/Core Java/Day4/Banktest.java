package prime_n0;

public class Banktest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Bank b;
b=new Icici();
System.out.println(b.get_roi());
b=new Hdfc();
System.out.println(b.get_roi());
	}

}
