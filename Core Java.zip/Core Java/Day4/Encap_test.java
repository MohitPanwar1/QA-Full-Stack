package prime_n0;

public class Encap_test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Encapsulation ob=new Encapsulation();
ob.setAcccount_no(3453);
ob.setBalance(786.89f);
System.out.println(ob.getAcccount_no());
System.out.println(ob.getBalance());
	}

}
