package prime_n0;

public class Encapsulation {
private int acccount_no;
private float balance;
public int getAcccount_no() {
	return acccount_no;
}
public void setAcccount_no(int acccount_no) {
	this.acccount_no = acccount_no;
}
public float getBalance() {
	return balance;
}
public void setBalance(float balance) {
	this.balance = balance;
}
}
