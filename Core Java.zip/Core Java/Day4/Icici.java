package prime_n0;

public class Icici extends Bank{
	public float get_roi()
	{
	return 8.7f;	
	}
}
