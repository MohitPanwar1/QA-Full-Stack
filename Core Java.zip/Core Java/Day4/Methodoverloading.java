package prime_n0;

public class Methodoverloading {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Methodoverloading ob=new Methodoverloading();
int a=ob.add(34,67);
int b=ob.add(45, 89, 67);
float c=ob.add(56.67f,89.56f);
System.out.println(a);
System.out.println(b);
System.out.println(c);
float d=ob.add(56,89.56f);
System.out.println(d);
	}
	int add(int x,int y)
	{
	int z=x+y;
	return z;
	}
	int add(int x,int y,int z)
	{
	int m=x+y+z;
	return m;
	}
	float add(float x,float y)
	{
		float z=x+y;
		return z;
		}
	float add(int x,float y)
	{
		float z=x+y;
		return z;
		}
}
