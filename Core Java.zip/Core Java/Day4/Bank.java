package prime_n0;

public class Bank {
public float get_roi()
{
return 0f;	
}
}
