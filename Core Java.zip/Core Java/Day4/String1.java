package prime_n0;

public class String1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="I am learning Java ";
int i=s.indexOf(' '),j=0;
while(i!=-1)
{
i=s.indexOf(' ',j);
if(i!=-1)
System.out.println(s.substring(j,i));
j=i+1;
	}
	}
}
