package prime_n0;

public class Hdfc extends Bank{
	public float get_roi()
	{
	return 9.6f;	
	}
}
