package day7;

import java.util.ArrayList;

public class Studentmarkstest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<Studentmarks> s=new ArrayList<Studentmarks>();
Studentmarks ramesh=new Studentmarks(1,"Ramesh",34,45);
Studentmarks rakesh=new Studentmarks(2,"Rakesh",56,67);
Studentmarks suresh=new Studentmarks(3,"Suresh",76,45);
Studentmarks preeti=new Studentmarks(4,"Preeti",64,39);
Studentmarkstest ex=new Studentmarkstest();
s.add(rakesh);
s.add(ramesh);
s.add(preeti);
s.add(suresh);
ex.display(s);
	}
	public void display(Studentmarks s)
	{
		System.out.println("ID"+s.stdid+"\nName:"+s.name+"\nPhysics:"+s.m1+"\nChemistry:"+s.m2+"\nAverage:"+s.f);
	}
public void display(ArrayList<Studentmarks> std)
{
	for(Studentmarks s:std)
	{
	System.out.println("===============================");
	s.average();
	System.out.println("ID"+s.stdid+"\nName:"+s.name+"\nPhysics:"+s.m1+"\nChemistry:"+s.m2+"\nAverage:"+s.f);
	}
}
}
