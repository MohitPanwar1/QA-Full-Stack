package programassignment;

public class Accounttest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
SB_Account Ram=new SB_Account(1,"Ram",25000.0f,4.0f);
SB_Account Shyam=new SB_Account(2,"Shyam",35000.0f,4.0f);
FD_Account Prashant=new FD_Account(3,"Prashant",20000.0f,6.0f);
Ram.deposit(5600);
Ram.withdrew(2000);
System.out.println(Ram.cal_interest());
System.out.println(Shyam.cal_interest());
System.out.println(Prashant.cal_interest());
System.out.println(Prashant.calc_maturity());
	}

}
