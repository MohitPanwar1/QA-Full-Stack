package day7;

public class Studentmarks {

	/**
	 * @param args
	 */
	int stdid;
	String name;
	int m1;
	int m2;
	float f;
	public void average()
	{
		f=(m1+m2)/2;
		
	}
	public Studentmarks(int id,String name,int phy,int chem)
	{
		
		this.stdid=id;
		this.name=name;
		this.m1=phy;
		this.m2=chem;
	}

}
