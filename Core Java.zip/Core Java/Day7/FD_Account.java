package programassignment;

public class FD_Account extends Account{
	FD_Account(int a, String n, float b, float r) {
		super(a, n, b, r);
		// TODO Auto-generated constructor stub
	}
	void deposit(int d)
	{
	balance=balance+d;	
	}
	float cal_interest()
	{
		return(balance*(this.rate/100));
	}
	float calc_maturity()
	{
		float maturity_amt=balance+cal_interest();
		return maturity_amt;
	}
}
