package programassignment;

public class Program12 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// TODO Auto-generated method stub
int f=1,c=1,sum=0;
for(int j=2;j<=30;j++)
	{
	for(int i=2;i<j;i++)
	{
		if(j%i==0)
	{
			f=0;
			break;
	}
	
	}
if(f==1)
{
	if(c<=2)
	{
	System.out.print(j+" ");
	c++;
	}
	else if(c==3)
	{
		sum=sum+j;
		c++;
	}
	else if(c==4)
	{
		System.out.print(sum+j+" ");
		sum=0;
		c=1;
	}
}
f=1;
	}
}
}
