package programassignment;

abstract public class Account {
int account_no;
String name;
float balance;
float rate;
Account(int a,String n,float b,float r)
{
this.account_no=a;	
this.name=n;
this.balance=b;
this.rate=r;
}
abstract void deposit(int d);
abstract float cal_interest();
}
