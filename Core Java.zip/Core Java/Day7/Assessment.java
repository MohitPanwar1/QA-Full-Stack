package exceluse;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Assessment {
	int sid,java,sel;
	float avg;
	String grade,sname;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Assessment s=new Assessment();
		s.read_excel();
		
		
		
	}
void read_excel()
	{

try {
	File f=new File("C:\\Users\\mohit.panwar\\Documents\\Assessment1.xlsx");
	for(int i=1;i<=3;i++)
	{
	int j=0;
	FileInputStream fis=new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet sh=wb.getSheet("Sheet1");
	XSSFRow rw=sh.getRow(i);
	XSSFCell c1=rw.getCell(j);
	int sid1=(int) c1.getNumericCellValue();
	j++;
	c1=rw.getCell(j);
	String sname=c1.getStringCellValue();
	j++;
	c1=rw.getCell(j);
	int java=(int)c1.getNumericCellValue();
	j++;
	c1=rw.getCell(j);
	int selenium=(int)c1.getNumericCellValue();
	j++;
	Assessment s1=new Assessment();
	float avg=s1.average(java,selenium);
	String g=s1.grade(avg);
	s1.writeexcel(i, j, avg, g);
	}
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	}

public void writeexcel(int r,int c,float a,String grade)
{
	try {
		
		File f=new File("C:\\Users\\mohit.panwar\\Documents\\Assessment1.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		
		XSSFRow row1=sh.getRow(r);
		XSSFCell cell1=row1.createCell(c);
		FileOutputStream fos =new FileOutputStream(f);
		cell1.setCellValue(a);
		c++;
		cell1=row1.createCell(c);
		cell1.setCellValue(grade);
		wb.write(fos);
}
	catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
float average(int j,int s)
{
return (float)(j+s)/2;	
}
String grade(float avg)
{
if(avg>=70)
	return("FDH");
else if(avg>=60)
	return("FD");
else if(avg>=50)
	return("SD");
else if(avg>=35)
	return("Pass");
else
	return("Fail");

}
}
