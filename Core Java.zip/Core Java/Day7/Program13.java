package programassignment;

public class Program13 
{
	public static void main(String args[])
	{
		System.out.print("5!=");
		int f=1;
for(int i=5;i>=2;i--)
{
f=f*i;	
System.out.print(i+"*");	
}
System.out.print("1="+f);
	}
}
