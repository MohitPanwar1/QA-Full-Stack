package programassignment;

public class Program1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
for(int i=3;i<=50;i++)
{
if(i%3==0&&!(i%5==0))
{
	System.out.print(i+" ");
}
}
	}

}
