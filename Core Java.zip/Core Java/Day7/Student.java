package exceluse;

public class Student {
int sid,java,sel;
float avg;
String grade,sname;
/*Student(int sid,String sname,int java,int sel)
{
this.sid=sid;
this.java=java;
this.sel=sel;
this.sname=sname;
}*/
}
