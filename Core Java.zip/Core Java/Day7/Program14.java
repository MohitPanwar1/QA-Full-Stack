package programassignment;

public class Program14 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int sum=0;
		for(int i=0;i<=200;i=i+77)
{
sum+=i;	
}
		System.out.println(sum);
	}

}
