package programassignment;

public class SB_Account extends Account{
SB_Account(int a, String n, float b, float r) {
		super(a, n, b, r);
		// TODO Auto-generated constructor stub
	}
void withdrew(int wd)
{
balance=balance-wd;	
}
void deposit(int d)
{
balance=balance+d;	
}
float cal_interest()
{
	return(balance*(this.rate/100));
}
}
