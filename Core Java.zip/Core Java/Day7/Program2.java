package programassignment;

public class Program2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n=67479;
int sum=0;
while(n>0)
{
int r=n%10;
if(r>5)
{
sum+=r;	
}
n=n/10;
}
System.out.println(sum);
	}

}
