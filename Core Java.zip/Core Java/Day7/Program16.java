package programassignment;

public class Program16 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i,j=99,k=82;
for(i=9;i>=2;i--)
{
	if(i%2!=0)
{
System.out.print(j+" ");
j=j-i;
}
	else
	{
System.out.print(k+" ");	
k=k-i;
}
	}


	}

}
