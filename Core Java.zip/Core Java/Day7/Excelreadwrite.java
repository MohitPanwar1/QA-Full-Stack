package exceluse;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class Excelreadwrite 
{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int i=0;
		Excelreadwrite ob1=new Excelreadwrite();
		for(i=0;i<9;i++)
		{
			int n=ob1.readsheet(i,0);
			System.out.println(n);
			ob1.prime(n);
		}

	}
	public int readsheet(int r,int c)
	{
		int n=0;
		try {
			File f=new File("C:\\Users\\mohit.panwar\\Documents\\mohit.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow row=sh.getRow(r);
			XSSFCell cell=row.getCell(c);
			n=(int)(cell.getNumericCellValue());
	}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
	}
	public void writeexcel(int r,int c,String sheet,int data)
	{
		try {
			File f=new File("C:\\Users\\mohit.panwar\\Documents\\mohit.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(sheet);
			
			XSSFRow row1=sh.createRow(r);
			XSSFCell cell1=row1.createCell(c);
			FileOutputStream fos =new FileOutputStream(f);
			cell1.setCellValue(Integer.toString(data));
			wb.write(fos);
	}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	int c=0,c1=0,c2=0;
	public void prime(int n)
	{
		Excelreadwrite ob=new Excelreadwrite();
		
		int f=0;
		for(int i=2;i<=n/2;i++)
		{
		if(n%i==0)
		{
			f=1;
			break;
		}
		}
		if(f==0)
		{
			ob.writeexcel(c, 0,"Sheet2",n);
			c++;
		}
		else if(n%2==0)
		{
			ob.writeexcel(c1,0,"Sheet3",n);
			c1++;
		}
		else
		{
			ob.writeexcel(c2,0,"Sheet4",n);
			c2++;
		}
			
	}
}

