package programassignment;

public class Program8 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// TODO Auto-generated method stub

for(int l=1;l<=5;l++)	
{
for(int i=4;i>=l;i--)
{
System.out.print(" ");	
}
for(int j=1;j<=l;j++)
{
System.out.print(l+" ");	
}
System.out.println();
}
for(int l=4;l>=1;l--)	
{
for(int i=4;i>=l;i--)
{
System.out.print(" ");	
}
for(int j=l;j>=1;j--)
{
System.out.print(l+" ");	
}
System.out.println();
}
}
}
