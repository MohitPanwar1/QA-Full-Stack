package programassignment;

public class Program15 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	int f=3;
	for(int i=2;i<=9;i++)
	{
		System.out.print(f+" ");
		f=f+i;
	}
	}
}
