package day7;
import java.util.*;
public class Arraylist {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> al=new ArrayList<String>();
al.add("Sanjay");
al.add("Manoj");
System.out.println(al);
for(String s:al)
{
System.out.println(s);	
}
}

}
