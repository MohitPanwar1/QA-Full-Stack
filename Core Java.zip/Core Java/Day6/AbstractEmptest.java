package libraryuse;

public class AbstractEmptest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Consultant cs=new Consultant(1,"RAMESH",200);
Fulltimeemploye ft=new Fulltimeemploye(2,"RAJU",2387);
int a=cs.cal_monthly_salary();
int b=ft.cal_monthly_salary();
System.out.println(a+"     "+b);
System.out.println(cs.getEid());
System.out.println(cs.getEname());
System.out.println(cs.getRateperunit());
System.out.println(ft.getEid());
System.out.println(ft.getEname());
System.out.println(ft.getRateperunit());
}

}
