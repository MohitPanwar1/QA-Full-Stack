package libraryuse;

public class Consultant extends Abstractemp{
Consultant(int eid, String ename, int rateperunit) {
		super(eid, ename, rateperunit);
		// TODO Auto-generated constructor stub
	}
int totalworkhour=23;
int cal_monthly_salary()
{
	int sal;
	sal=totalworkhour*rateperunit;
	return sal;
}
}
