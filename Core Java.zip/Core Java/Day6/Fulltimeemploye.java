package libraryuse;

public class Fulltimeemploye extends Abstractemp {
	Fulltimeemploye(int eid, String ename, int rateperunit) {
		super(eid, ename, rateperunit);
		// TODO Auto-generated constructor stub
	}
	int totaldayswork=89;
	int cal_monthly_salary()
	{
		int sal;
		sal=totaldayswork*rateperunit;
		return sal;
	}
}
