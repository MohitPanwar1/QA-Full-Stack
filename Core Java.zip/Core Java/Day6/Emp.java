package libraryuse;

public class Emp {
static int b=0;
int c=0;
public Emp()
{
c++;
b++;
}
}
