package prime_n0;

public class Electricitybill {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int unit=225;
    float bill=0.0f;
    if(unit<=100)
    {
    	bill=unit*1.5f;
    	}
    else if(unit<=200.0f)
    {
    	bill=150+(unit-100)*2.0f;
    	
    }
    else if(unit<=250.0f)
    {
    	bill=350+(unit-200)*2.5f;
	}
	else
    {
		bill=475+(unit-250)*4.0f;
		}
    System.out.println(bill);
	}

}
