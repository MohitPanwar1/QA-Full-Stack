package libraryuse;

public class Emptest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Emp e1=new Emp();
System.out.println(Emp.b+"    "+e1.c);
Emp e2=new Emp();
System.out.println(Emp.b+"    "+e2.c);
	}

}
