package sele;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

public class Demokeywordmain extends Demokeywordbase{
	WebDriver dr;
	static Demokeywordmain ob=new Demokeywordmain();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=5;i++)
		{
ob.read_excel(i);
		}
	}
	void read_excel(int i)
	{
		
	File f=new File("C:\\Users\\mohit.panwar\\Documents\\Demokeyword.xlsx");
	try {
		FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow rw=sh.getRow(i);
			XSSFCell c=rw.getCell(2);
			String s=c.getStringCellValue();
			
			c=rw.getCell(3);
			String x=c.getStringCellValue();
			
			c=rw.getCell(4);
			String d=c.getStringCellValue();
			switch(s)
			{
			case "launch_browser":
				dr=launch_browser(d);
				break;
			case "enter_id":
				enter_id(dr,x,d);
				break;
			case "enter_password":
				enter_password(dr,x,d);
				break;
			case "click_login":
				click_login(dr,x);
				break;
			case "verify":
				verify(dr,x,d);
				break;
			}
			} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
