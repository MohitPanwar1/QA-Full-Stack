package sele;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demokeywordbase {
	WebDriver dr;
WebDriver launch_browser(String url) 
{
	System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
	WebDriver dr=new ChromeDriver();
	dr.get(url);
	return dr;
}
void enter_id(WebDriver dr,String xid,String sid)
{
dr.findElement(By.className("ico-login")).click();
System.out.print("Login");
dr.findElement(By.xpath(xid)).sendKeys(sid);
}
void enter_password(WebDriver dr,String xpass,String password)
{
dr.findElement(By.xpath(xpass)).sendKeys(password);
}
void click_login(WebDriver dr,String xlogin)
{
	dr.findElement(By.xpath(xlogin)).click();
}
void verify(WebDriver dr,String xaccount,String expect)
{
	String s=dr.findElement(By.xpath(xaccount)).getText();
	if(s.equals(expect))
	{
		System.out.println("Account verified");
	}	


}

}
