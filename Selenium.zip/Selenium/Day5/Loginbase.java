package testng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Loginbase {
	String login()
	{
	System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com/");
	dr.findElement(By.className("ico-login")).click();
	dr.findElement(By.id("Email")).sendKeys("abcd45724@gmail.com");
	dr.findElement(By.id("Password")).sendKeys("12345678");
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	String s=dr.findElement(By.className("account")).getText();
	return s;
	}
}
