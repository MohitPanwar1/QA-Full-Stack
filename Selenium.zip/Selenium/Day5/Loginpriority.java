package testng;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Loginpriority extends LoginpriorityBase {
  
  String eid,pass;
  String out;
  WebDriver dr;
  @BeforeMethod
  void BM()
  {
	  dr=login();
	  
  }
  @Test
  public void validemail_validpassword() {
	  eid="anil12@gmail.com";
	  pass="pass123$";
	  String s=loginpass(dr,eid,pass);
	  Assert.assertEquals(s, eid);
  }
  @Test
  public void validemail_validpassword1() {
	  eid="anil12@gmail.com";
	  pass="pass12";
	  String s=loginpass(dr,eid,pass);
	  SoftAssert sa =new SoftAssert();
	  sa.assertEquals(s, eid);
	  System.out.println("SoftAssert");
	  sa.assertAll();
  }
  @Test
  public void validemail_validpassword2() {
	  eid="anil12gmailcom";
	  pass="pass12";
	  String s=loginpass(dr,eid,pass);
	  Assert.assertEquals(s,eid);
	  
  }
  @AfterMethod
  void AM()
  {
	  dr.close();
  }
}
