package testng;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class BeforeAfterMethod {


	@BeforeClass
	public void BC()
	{
		System.out.println("BC");
	}
	@AfterClass
	public void FC()
	{
		System.out.println("FC");
	}
	@AfterClass
	public void AC1()
	{
		System.out.println("AC1");
	}
	@BeforeMethod
	public void BM()
	{
		System.out.println("BM");
	}
	@BeforeMethod
	public void BM1()
	{
		System.out.println("BM1");
	}
	/*@AfterMethod
	public void AM()
	{
		System.out.println("AM");
	}*/
  @Test(priority=3)
  public void f() {
	  System.out.println("F");
	
  }
  @Test(priority=2)
  public void c() {
	  System.out.println("C");
	
  }
  @Test(priority=1)
  public void x() {
	  System.out.println("X");
	
  }
}
