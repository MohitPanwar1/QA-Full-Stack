package testng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginpriorityBase {
	WebDriver login()
	{
	System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com/");
	return dr;
	}
	String loginpass(WebDriver dr,String eid,String pass)
	{
		String s="";
	dr.findElement(By.className("ico-login")).click();
	dr.findElement(By.id("Email")).sendKeys(eid);
	dr.findElement(By.id("Password")).sendKeys(pass);
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	if(dr.findElement(By.className("account")).isDisplayed())
	{
	s=dr.findElement(By.className("account")).getText();
	}
	return s;
	}
}
