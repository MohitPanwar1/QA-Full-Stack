package testng;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Loginassert extends Loginbase{
	String ac=login();
	String ex;
  @Test
  public void tc1() {
	  ex="abcd45724@gmail.com";
	  Assert.assertEquals(ac, ex);
  }
  @Test
  public void tc2() {  
	  ex="abcd4524@gmail.com";
	  Assert.assertEquals(ac, ex);
  }
}
