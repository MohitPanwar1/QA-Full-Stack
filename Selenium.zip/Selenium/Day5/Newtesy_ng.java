package testng;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import sele.Base_class;

public class Newtesy_ng extends Base_class{
  @Test
  public void tc1() {
	  System.out.println("in tc1");
	  tc2();
	  String a="http://demo.guru99.com/test/delete_customer.php/";
		WebDriver dr=open_browser(a);
  }
  public void tc2() {
	  System.out.println("in tc2");
  }
  @Test
  public void tc3() {
	  String a="http://demo.guru99.com/test/delete_customer.php/";
	  WebDriver dr=open_browser(a);
	  
	  String name="cusid",sendkeys="sgssdhsdg";
	 cancel_alert(dr,name,sendkeys);
	  System.out.println("in tc3");
  }
}
