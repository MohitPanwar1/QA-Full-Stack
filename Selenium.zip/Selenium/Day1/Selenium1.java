package sele;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Selenium1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
WebDriver dr=new ChromeDriver();
dr.get("https://www.facebook.com");
dr.findElement(By.id("email")).sendKeys("girishindia95@gmail.com");
dr.findElement(By.id("pass")).sendKeys("newfbp@55");
dr.findElement(By.id("loginbutton")).click();
String profilename,title=dr.getTitle();
profilename=dr.findElement(By.className("_1vp5")).getText();
System.out.println("Title "+title+"\nProfile Name "+profilename);

	}

}
