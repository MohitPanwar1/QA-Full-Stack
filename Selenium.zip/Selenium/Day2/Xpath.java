package sele;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Xpath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.facebook.com");*/
		//dr.findElement(By.xpath("//input[@id='email']")).sendKeys("abc");
		//dr.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("abcd");
		//String s=dr.findElement(By.xpath("//*[contains(text(),'Log In')]")).getText();
		//System.out.println(s);
		//dr.findElement(By.xpath("//input[@name='firstname']//following::input[1]")).sendKeys("abcde");
	
	System.setProperty("webdriver.ie.driver","D:\\Driver\\IEDriverServer.exe" );
	WebDriver dr=new InternetExplorerDriver();
	dr.get("https://www.facebook.com");
	
	}

}
