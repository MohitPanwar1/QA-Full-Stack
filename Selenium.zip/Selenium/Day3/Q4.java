package sele;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Q4 {
static Q4 ob=new Q4();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
for(int i=1;i<=3;i++)
{
ob.read_excel(i);	
}
	}
	void read_excel(int i)
	{
		int c1=0;
		File f=new File("C:\\Users\\mohit.panwar\\Documents\\Q4.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow rw=sh.getRow(i);
				XSSFCell c=rw.getCell(c1);
				String s=c.getStringCellValue();
				c1++;
				c=rw.getCell(c1);
				String s1=c.getStringCellValue();
				c1++;
				c=rw.getCell(c1);
				String s2=c.getStringCellValue();
				String s3=ob.check_status(s,s1,s2);
				ob.write_excel(i, s3,s2);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	String check_status(String a,String b,String c)
	{
	System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com/");
	dr.findElement(By.className("ico-login")).click();
	dr.findElement(By.id("Email")).sendKeys(a);
	dr.findElement(By.id("Password")).sendKeys(b);
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	String s=dr.findElement(By.className("account")).getText();
	if(s.equals(c))
	{
		System.out.println("Account verified");
	}
	dr.findElement(By.className("ico-logout")).click();
	//dr.close();
	return s;
	}
	void write_excel(int i,String a,String b)
	{
		File f=new File("C:\\Users\\mohit.panwar\\Documents\\Q4.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow rw=sh.getRow(i);
				XSSFCell c=rw.createCell(3);
				FileOutputStream fos=new FileOutputStream(f);
				if(a.equals(b))
				{
				c.setCellValue("Pass");
				}
				else
					c.setCellValue("Fail");
				wb.write(fos);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	



	}
}
