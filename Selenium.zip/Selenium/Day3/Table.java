package sele;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Table {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.w3schools.com/html//html_tables.asp");
		//    //*[@id="customers"]/tbody/tr[2]/td[2]
		//    //*[@id="customers"]/tbody/tr[1]/th[2]
		String data;
		for(int j=1;j<=3;j++)
		{
	
	String xpath="//*[@id=\"customers\"]/tbody/tr["+1+"]/th["+j+"]";
	data=dr.findElement(By.xpath(xpath)).getText();
	System.out.println(data);
		}
		
		
		
		for(int i=2;i<=7;i++)
		{
			for(int j=1;j<=3;j++)
			{
		
		String xpath="//*[@id=\"customers\"]/tbody/tr["+i+"]/td["+j+"]";
		data=dr.findElement(By.xpath(xpath)).getText();
		System.out.print(data);
			}
			System.out.println();
		}
	}

}
