package sele;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Q5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		String s=dr.getTitle();
		if(s.equals("Online Bookstore"))
		{
			System.out.println("Title Verified");
		}
		dr.findElement(By.linkText("Databases")).click();
		dr.findElement(By.name("DoSearch")).click();
		dr.findElement(By.linkText("Web Database Development")).click();
		String str=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/h1")).getText();
		if(str.equals("Web Database Development"))
		{
			System.out.println("Name verified ");
		}
		String p=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/table/tbody/tr/td[2]")).getText();
		p=p.substring(8);
		double price=Double.parseDouble(p);
		dr.findElement(By.name("quantity")).clear();
		dr.findElement(By.name("quantity")).sendKeys("2");
		dr.findElement(By.name("Insert1")).click();
		String s2=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/p")).getText();
	s2=s2.substring(8);
	double total=Double.parseDouble(s2);
	if(total==79.98)
		System.out.println("Total is verified");
	dr.close();
	}

}
