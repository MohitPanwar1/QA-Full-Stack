package sele;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		String s=dr.getTitle();
		if(s.equals("Online Bookstore"))
		{
			System.out.println("Title Verified");
		}
		dr.findElement(By.linkText("Databases")).click();
		dr.findElement(By.name("DoSearch")).click();
		dr.close();
	}

}
