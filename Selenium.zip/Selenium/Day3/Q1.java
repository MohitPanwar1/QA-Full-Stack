package sele;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		String s=dr.getTitle();
		if(s.equals("Demo Web Shop"))
		{
			System.out.println("Title Verified");
		}
		dr.findElement(By.className("ico-register")).click();
		List rb = dr.findElements(By.name("Gender"));
		((WebElement) rb.get(0)).click();
		dr.findElement(By.id("FirstName")).sendKeys("Ramesh");
		dr.findElement(By.id("LastName")).sendKeys("Kumar");
		dr.findElement(By.id("Email")).sendKeys("rameshmp1@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("abc1234");
		dr.findElement(By.id("ConfirmPassword")).sendKeys("abc1234");
		dr.findElement(By.id("register-button")).click();
		dr.findElement(By.className("ico-logout")).click();
		dr.close();
	}

}
