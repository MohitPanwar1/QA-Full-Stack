package sele;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Navigation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://facebook.com");
		dr.findElement(By.id("u_0_a")).click();
		dr.navigate().back();
		dr.navigate().forward();
		dr.navigate().refresh();
		dr.navigate().to("https://google.com");
	}

}
