package sele;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WrongTestcase {
	static WrongTestcase ob=new WrongTestcase();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=4;i++)
		{
		ob.read_excel(i);	
		}
			}
			void read_excel(int i)
			{
				int c1=0;
				File f=new File("C:\\Users\\mohit.panwar\\Documents\\WrongTestcase.xlsx");
				try {
					FileInputStream fis=new FileInputStream(f);
						XSSFWorkbook wb=new XSSFWorkbook(fis);
						XSSFSheet sh=wb.getSheet("Sheet1");
						XSSFRow rw=sh.getRow(i);
						XSSFCell c=rw.getCell(c1);
						String s=c.getStringCellValue();
						c1++;
						c=rw.getCell(c1);
						String s1=c.getStringCellValue();
						c1++;
						c=rw.getCell(c1);
						String s2=c.getStringCellValue();
						String s3=ob.check_status(i,s,s1,s2);
						ob.write_excel(i, s3,s2);
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			String check_status(int i,String a,String b,String c)
			{
			System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
			WebDriver dr=new ChromeDriver();
			dr.get("http://demowebshop.tricentis.com/");
			dr.findElement(By.className("ico-login")).click();
			dr.findElement(By.id("Email")).sendKeys(a);
			dr.findElement(By.id("Password")).sendKeys(b);
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
			String s="";
			switch(i)
			{
			case 1:
				s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
				break;
			case 2:
				s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
				break;
			case 3:
				s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).getText();
				break;
			case 4:
				s=dr.findElement(By.className("account")).getText();
			}
			System.out.println(s);
			return s;
			}
			void write_excel(int i,String a,String b)
			{
				File f=new File("C:\\Users\\mohit.panwar\\Documents\\WrongTestcase.xlsx");
				try {
					FileInputStream fis=new FileInputStream(f);
						XSSFWorkbook wb=new XSSFWorkbook(fis);
						XSSFSheet sh=wb.getSheet("Sheet1");
						XSSFRow rw=sh.getRow(i);
						XSSFCell c=rw.createCell(3);
						FileOutputStream fos=new FileOutputStream(f);
						if(a.equals(b))
						{
						c.setCellValue(b);
						}
						else
							c.setCellValue("Fail");
						wb.write(fos);
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	

	}

}
