package sele;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Q6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		dr.findElement(By.linkText("Databases")).click();
		dr.findElement(By.name("DoSearch")).click();
		dr.findElement(By.linkText("Web Database Development")).click();
		dr.findElement(By.name("quantity")).clear();
		dr.findElement(By.name("quantity")).sendKeys("2");
		dr.findElement(By.name("Insert1")).click();
		dr.findElement(By.linkText("Search")).click();
		dr.findElement(By.name("DoSearch")).click();
		dr.findElement(By.linkText("Programming Perl")).click();
		dr.findElement(By.name("quantity")).clear();
		dr.findElement(By.name("quantity")).sendKeys("4");
		dr.findElement(By.name("Insert1")).click();
		dr.findElement(By.linkText("Search")).click();
		dr.findElement(By.name("DoSearch")).click();
		dr.findElement(By.linkText("MySQL")).click();
		dr.findElement(By.name("quantity")).clear();
		dr.findElement(By.name("quantity")).sendKeys("3");
		dr.findElement(By.name("Insert1")).click();
		String a1=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[1]")).getText();
		String a2=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[2]")).getText();
		a2=a2.substring(1);
		double p1=Double.parseDouble(a2);
		String a3=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[3]/input")).getAttribute("value");
		int q1=Integer.parseInt(a3);
		String a4=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[4]")).getText();
		a4=a4.substring(1);
		double t1=Double.parseDouble(a4);
		if((a1.equals("Web Database Development "))&&((p1==39.99)&&(q1==2)&&(t1==79.98)))
		{
			System.out.println("First Product Verified");
		}
		else
		{
			System.out.println("First Product not Verified");
		}
		String b1=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[3]/td[1]")).getText();
		String b2=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[3]/td[2]")).getText();
		b2=b2.substring(1);
		double p2=Double.parseDouble(b2);
		String b3=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[3]/td[3]/input")).getAttribute("value");
		int q2=Integer.parseInt(b3);
		String b4=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[3]/td[4]")).getText();
		b4=b4.substring(1);
		double t2=Double.parseDouble(b4);
		
		if(b1.equals("Programming Perl ")&&p2==39.96&&q2==4&&t2==159.84)
			System.out.println("Second Product Verified");
		else
			System.out.println("Second Product not Verified");
		String c1=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[4]/td[1]")).getText();
		String c2=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[4]/td[2]")).getText();
		c2=c2.substring(1);
		double p3=Double.parseDouble(c2);
		String c3=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[4]/td[3]/input")).getAttribute("value");
		int q3=Integer.parseInt(c3);
		String c4=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[4]/td[4]")).getText();
		c4=c4.substring(1);
		double t3=Double.parseDouble(c4);
		if(c1.equals("MySQL ")&&p3==39.99&&q3==3&&t3==119.97)
			System.out.println("Third Product Verified");
		else
			System.out.println("Third Product not Verified");
		String total=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/p")).getText();
		total=total.substring(8);
		double t=Double.parseDouble(total);
		if(t==359.79)
			System.out.println("Total Product Verified");
		else
			System.out.println("Total Product not Verified");
		dr.close();
		
	}

}
