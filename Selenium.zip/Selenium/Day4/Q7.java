package sele;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Q7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/RegistrationForm/Registration.php");
		dr.findElement(By.name("user_login")).sendKeys("abc12ab1");
		dr.findElement(By.name("user_password")).sendKeys("cd123c12");
		
		dr.findElement(By.name("first_name")).sendKeys("A");
		dr.findElement(By.name("last_name")).sendKeys("K");
		dr.findElement(By.name("email")).sendKeys("abc@gamil.com");
		dr.findElement(By.name("address1")).sendKeys("Noida");
		dr.findElement(By.name("city")).sendKeys("GB");
		Select ob;
		ob=new Select(dr.findElement(By.name("state_id")));
		ob.selectByVisibleText("Alaska");
		dr.findElement(By.name("city")).sendKeys("GB");
		ob=new Select(dr.findElement(By.name("country_id")));
		ob.selectByVisibleText("India");
		dr.findElement(By.name("phone_home")).sendKeys("123456788");
		dr.findElement(By.name("phone_work")).sendKeys("5667789");
		ob=new Select(dr.findElement(By.name("language_id")));
		ob.selectByVisibleText("English");
		ob=new Select(dr.findElement(By.name("age_id")));
		ob.selectByVisibleText("18-24");
		ob=new Select(dr.findElement(By.name("gender_id")));
		ob.selectByVisibleText("Male");
		ob=new Select(dr.findElement(By.name("education_id")));
		ob.selectByVisibleText("College");
		ob=new Select(dr.findElement(By.name("income_id")));
		ob.selectByVisibleText("over $75,000");
		dr.findElement(By.name("note")).sendKeys("Not required");
		dr.findElement(By.name("Insert")).click();
		String s=dr.findElement(By.linkText("abc12ab1")).getText();
		if(s.equals("abc12ab1"))
		{
			System.out.println("Registration Successful");
		}
		else
		{
		System.out.println("Registration Successful");
		}
		dr.close();
	}

}
