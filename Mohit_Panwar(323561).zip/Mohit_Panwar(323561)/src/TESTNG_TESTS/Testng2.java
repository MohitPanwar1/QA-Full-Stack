package TESTNG_TESTS;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import UTILITIES.ReadExcel;

public class Testng2 extends Testng1{
	@Test
	public void f9()
	{
		go_to_cart();
	}
	int i=0;
	@DataProvider(name="dataprovider2")
	  public String[][] d2() 
	  {
		  ReadExcel ob=new ReadExcel();
		String s1[][]=ob.read_excel1(); 
		return s1;
	  }
  @Test(dataProvider="dataprovider2")
  public void f10(String p,String t) 
  {
	  boolean b=check_cart(p,t,i);
	  i++;
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(b, true);
  }
}
