package TESTNG_TESTS;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


import BASE_CLASSES.Shopping_Cart;
import UTILITIES.ReadExcel;

public class Testng1 extends Shopping_Cart{
  @Test
  public void f() {
	  String title=verify_title();
	  Assert.assertEquals(title, "Online Bookstore");
  }
  @DataProvider(name="dataprovider1")
  public String[][] d1() 
  {
	  ReadExcel ob=new ReadExcel();
	String s[][]=ob.read_excel(); 
	return s;
  }
  @Test
  public void f1() {
	  String text=verify_text();
	  Assert.assertEquals(text, "Search Products");
  }
  @Test(dataProvider="dataprovider1")
 public void f2(String c,String s,String q)
 {
	 click_search(c,s);
	 f3();
	 f4();
	 f5();
	 f6(q);
 }
  public void f3()
  {
	  String title=verify_search_title();
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(title, "SearchResults");
  }
  public void f4()
  {
	  click_product();
  }
  public void f5()
  {
	  String title=verify_book_title();
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(title, "ProductDetail");
  }
  
  public void f6(String q)
  {
  add_product(q);
  
  }
  }

