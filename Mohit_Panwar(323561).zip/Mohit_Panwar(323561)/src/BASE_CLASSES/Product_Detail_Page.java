package BASE_CLASSES;

import org.openqa.selenium.By;

public class Product_Detail_Page extends Search_Results_Page{
	public String verify_book_title()
	{
		log.info("Book title is verified");
	return (dr.getTitle());	
	}
	public void add_product(String q)
	{
		log.info("Product is added");
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).clear();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).sendKeys(q);
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[2]/input[1]")).click();
		dr.findElement(By.xpath("/html/body/table[2]/tbody/tr/td/a[1]")).click();
	}
}
