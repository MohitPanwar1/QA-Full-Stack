package BASE_CLASSES;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import sun.rmi.runtime.Log;

public class Home_Page {
	Logger log;
	
	WebDriver dr;
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[2]/td/input")
	WebElement enter_text;
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input")
	WebElement submit;
public String verify_title()
{
	System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
	dr=new ChromeDriver();
	dr.get("http://examples.codecharge.com/Store/Default.php");
	log=log=Logger.getLogger("devpinoyLogger");
	String s=dr.getTitle();
	log.info("Title is verified");
	return s;
	}


public String verify_text()
{
	PageFactory.initElements(dr,this);
	log.info("Text is verified");
	return (dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[1]/tbody/tr/th")).getText());
	
}
public void click_search(String c,String s)
{
	WebElement we=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select"));
	Select sel=new Select(we);
    sel.selectByVisibleText(c);
    enter_text.sendKeys(s);
    log.info("Clicked on Search");
    submit.click();
}
}
