package BASE_CLASSES;

import org.openqa.selenium.By;

public class Search_Results_Page extends Home_Page{
public String verify_search_title()
{
	log.info("Search title is verified");
return (dr.getTitle());	

}
public void click_product()
{
dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).click();	
log.info("Clicked on product");
}
}
