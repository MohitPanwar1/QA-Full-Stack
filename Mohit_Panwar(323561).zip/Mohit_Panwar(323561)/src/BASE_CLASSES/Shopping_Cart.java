package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Shopping_Cart extends Product_Detail_Page{
	public void go_to_cart()
	{
		log.info("Go to cart");
		dr.findElement(By.xpath("/html/body/table[2]/tbody/tr/td/a[3]")).click();
	}
public boolean check_cart(String p,String t,int i)
{
	if(i==0)
	{
		
	String p1="Beginning ASP Databases ";
    
    String t1="39.99";
    t="$"+t;
    log.info("First product and total is verified");
    if(p.equals(p1)&&t.equals(t1))
    {
    	return true;
    }
    else
    	return false;
}

else
{
String p1="Perl and CGI for the World Wide Web ";
    
    String t1="30.38";
    t="$"+t;
    log.info("Second product and total is verified");
    if(p.equals(p1)&&t.equals(t1))
    {
    	return true;
    }
    else
    	return false;
}
}
}
