package UTILITIES;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
public String[][] read_excel()
{
	String[][] s=new String[2][3];
	try {
		int c=0;
		File f=new File("C:\\Users\\mohit.panwar\\Documents\\Selenium_Exam.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		XSSFRow row=sh.getRow(2);
		XSSFCell cell=row.getCell(c);
		s[0][0]=cell.getStringCellValue();
		c++;
		cell=row.getCell(c);
		s[0][1]=cell.getStringCellValue();
		c++;
		cell=row.getCell(c);
		int q=(int) cell.getNumericCellValue();
		s[0][2]=Integer.toString(q);
		
		row=sh.getRow(3);
		c=0;
		cell=row.getCell(c);
		s[1][0]=cell.getStringCellValue();
		c++;
		cell=row.getCell(c);
		s[1][1]=cell.getStringCellValue();
		c++;
		cell=row.getCell(c);
		q=(int) cell.getNumericCellValue();
		s[1][2]=Integer.toString(q);
		
}
	catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return s;
}
public String[][] read_excel1()
{
	String[][] s1=new String[2][2];
	try {
		
		File f=new File("C:\\Users\\mohit.panwar\\Documents\\Selenium_Exam.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet2");
		XSSFRow row=sh.getRow(2);
		XSSFCell cell=row.getCell(0);
		s1[0][0]=cell.getStringCellValue();
		cell=row.getCell(1);
		double r=cell.getNumericCellValue();
		s1[0][1]=Double.toString(r);
		row=sh.getRow(3);
		
		cell=row.getCell(0);
		s1[1][0]=cell.getStringCellValue();
		
		cell=row.getCell(1);
		r=cell.getNumericCellValue();
		s1[1][1]=Double.toString(r);
		
}
	catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return s1;
}
}
