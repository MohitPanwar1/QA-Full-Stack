package excelnew1;

public class Owl extends Bird{
	Owl(String n,int a,String f)
	{
		super();
		this.bird_name=n;
		this.age=a;
		this.food=f;
	}
	void activity()
	{
		System.out.println("Eyesight is a particular characteristic of the owl that aids in nocturnal prey capture.");

	}
	void habitat()
	{
		System.out.println();
	}
	void display()
	{
	System.out.println("Name : "+this.bird_name);
	System.out.println("Age : "+this.age);
	System.out.println("Food : "+this.food);
	}
}
