package excelnew1;

public class Parrot extends Bird{
	Parrot(String n,int a,String f)
	{
		super();
		this.bird_name=n;
		this.age=a;
		this.food=f;
	}
void activity()
{
	System.out.println("Many parrots can imitate human speech or other sounds.");

}
void habitat()
{
	System.out.println("Parrots are found in warm climates all over most of the world.");
}
void display()
{
System.out.println("Name : "+this.bird_name);
System.out.println("Age : "+this.age);
System.out.println("Food : "+this.food);
}
}
