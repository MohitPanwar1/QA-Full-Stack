package excelnew1;

import java.util.ArrayList;

public class ElectricBill {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<Excelassessment1> ar=new ArrayList<Excelassessment1>();
for(int i=1;i<=3;i++)
{
Excelassessment1 ob=new Excelassessment1();	
ob.read_excel(i);
ob.price(ob.product_rate,ob.unit_purchased);
ob.product_Grade(ob.price);
ob.write_excel(i,ob.price,ob.grade);
ar.add(ob);
}
	
}

}
