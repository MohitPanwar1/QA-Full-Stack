package excelnew1;

public class BirdTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Parrot p1=new Parrot("Parrot 1",2,"fruit and flowers");
p1.display();
p1.habitat();
p1.activity();
Parrot p2=new Parrot("Parrot 2",2,"buds and nuts");
p2.display();
p2.habitat();
p2.activity();
Parrot p3=new Parrot("Parrot 3",2,"Small Creatures");
p2.display();
p3.habitat();
p3.activity();
Owl o1=new Owl("Owl 1",4,"Insects");
p1.display();
p1.habitat();
p1.activity();
Owl o2=new Owl("Owl 1",3,"Small Birds");
o2.display();
o2.habitat();
o2.activity();

	}

}
