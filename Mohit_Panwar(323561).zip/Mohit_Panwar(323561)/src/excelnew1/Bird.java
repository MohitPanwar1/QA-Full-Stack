package excelnew1;

public abstract class Bird {
String bird_name;
String food;
int age;
abstract void habitat();
abstract void activity();

	}


