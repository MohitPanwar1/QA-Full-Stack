package excelnew1;

public class Stringques {
public static void main(String args[])
{
	String s="I have learnt loops, opps concepts, inheritance, exception handling, arraylist and string handling";
	int j=0;
	int v=0;
	char c;
	for(int i=0;i<s.length();i++)
	{
		c=s.charAt(i);
		if(c==' ')
		{
			if(v>=3)
			{
				if(s.charAt(i-1)==',')
				System.out.println(s.substring(j,i-1));
				else
					System.out.println(s.substring(j,i));
			}
			v=0;
			j=i+1;
		}
		else
		{
			if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||c=='A'||c=='E'||c=='I'||c=='O'||c=='U')
			{
				v++;
			}
		}
	}
	}
}
