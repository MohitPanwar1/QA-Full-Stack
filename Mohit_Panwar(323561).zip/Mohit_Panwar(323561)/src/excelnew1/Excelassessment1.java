package excelnew1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excelassessment1 {
	int pid,product_rate,unit_purchased,price;
	String product_name,grade;
void read_excel(int i)
{
	int c1=0;
	File f=new File("C:\\Users\\mohit.panwar\\Documents\\ElectricityBill.xlsx");
	try {
		FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow rw=sh.getRow(i);
			XSSFCell c=rw.getCell(c1);
			this.pid=(int)c.getNumericCellValue();
			c1++;
			c=rw.getCell(c1);
			this.product_name=c.getStringCellValue();
			c1++;
			c=rw.getCell(c1);
			this.product_rate=(int)c.getNumericCellValue();
			c1++;
			c=rw.getCell(c1);
			this.unit_purchased=(int)c.getNumericCellValue();
			
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
void write_excel(int i,int price,String grade)
{
	File f=new File("C:\\Users\\mohit.panwar\\Documents\\ElectricityBill.xlsx");
	try {
		FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow rw=sh.getRow(i);
			XSSFCell c=rw.createCell(4);
			FileOutputStream fos=new FileOutputStream(f);
			c.setCellValue(price);
			c=rw.createCell(5);
			c.setCellValue(grade);
			wb.write(fos);
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	



}
void price(int a,int b)
{
this.price= a*b;	
}
void product_Grade(int n)
{
if(n>=25000)
	this.grade= "GradeB";
else
	this.grade="GradeA";
}
}
